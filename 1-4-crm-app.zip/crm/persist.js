// Persistence of the SQLite file in Google Firestore (REST, service-account auth, no extra dependencies).
const crypto = require('crypto');
const fs = require('fs');
const zlib = require('zlib');

const KEY_FILE = process.env.GOOGLE_SERVICE_ACCOUNT_FILE || '/etc/secrets/firebase-key.json';
const COLL = process.env.FIRESTORE_COLLECTION || 'crm_state';
const CHUNK = 500000; // chars of base64 per document (limit is ~1 MB)
let creds = null;
try { creds = JSON.parse(fs.readFileSync(KEY_FILE, 'utf8')); } catch { creds = null; }
const enabled = !!creds;
let tok = null, tokExp = 0;

const b64u = b => Buffer.from(b).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
async function token() {
  if (tok && Date.now() < tokExp - 60000) return tok;
  const now = Math.floor(Date.now() / 1000);
  const head = b64u(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claim = b64u(JSON.stringify({ iss: creds.client_email, scope: 'https://www.googleapis.com/auth/datastore https://www.googleapis.com/auth/cloud-platform', aud: 'https://oauth2.googleapis.com/token', iat: now, exp: now + 3600 }));
  const sig = crypto.createSign('RSA-SHA256').update(head + '.' + claim).sign(creds.private_key);
  const jwt = head + '.' + claim + '.' + b64u(sig);
  const r = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=' + jwt });
  const j = await r.json();
  if (!j.access_token) throw new Error('token: ' + JSON.stringify(j).slice(0, 200));
  tok = j.access_token; tokExp = Date.now() + (j.expires_in || 3600) * 1000;
  return tok;
}
const base = () => `https://firestore.googleapis.com/v1/projects/${creds.project_id}/databases/(default)/documents/${COLL}`;
async function fs_(method, id, body) {
  const r = await fetch(`${base()}/${id}`, { method, headers: { Authorization: 'Bearer ' + await token(), 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  if (r.status === 404 && method === 'GET') return null;
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`firestore ${method} ${id}: ${r.status} ${JSON.stringify(j).slice(0, 200)}`);
  return j;
}

async function save(file) {
  if (!enabled) return;
  const data = zlib.gzipSync(fs.readFileSync(file)).toString('base64');
  const n = Math.ceil(data.length / CHUNK) || 1;
  for (let i = 0; i < n; i++) await fs_('PATCH', 'chunk_' + i, { fields: { data: { stringValue: data.slice(i * CHUNK, (i + 1) * CHUNK) } } });
  await fs_('PATCH', 'meta', { fields: { n: { integerValue: String(n) }, saved_at: { stringValue: new Date().toISOString() }, bytes: { integerValue: String(data.length) } } });
}
async function restore(file) {
  if (!enabled) return false;
  const meta = await fs_('GET', 'meta');
  if (!meta) return false;
  const n = Number(meta.fields.n.integerValue);
  let data = '';
  for (let i = 0; i < n; i++) data += (await fs_('GET', 'chunk_' + i)).fields.data.stringValue;
  fs.writeFileSync(file, zlib.gunzipSync(Buffer.from(data, 'base64')));
  return true;
}
module.exports = { enabled, save, restore };
