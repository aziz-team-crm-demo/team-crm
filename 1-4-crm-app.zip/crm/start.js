// Boot: restore the database from Firestore (if configured and present), then start the server.
const path = require('path');
const fs = require('fs');
const persist = require('./persist');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB = path.join(DATA_DIR, 'crm.db');
fs.mkdirSync(DATA_DIR, { recursive: true });

(async () => {
  if (persist.enabled) {
    try {
      for (const f of [DB, DB + '-wal', DB + '-shm']) fs.rmSync(f, { force: true });
      const ok = await persist.restore(DB);
      console.log(ok ? 'Restored database from Firestore' : 'No saved database in Firestore yet (fresh start)');
    } catch (e) { console.error('RESTORE FAILED, refusing to start with empty data:', e.message); process.exit(1); }
  } else console.log('Firestore persistence is OFF (no service account key found)');
  require('./server.js');
})();
