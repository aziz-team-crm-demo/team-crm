/* CRM SPA */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let ME = null;
let CUSTOMERS_CACHE = [];

const MODULES = { customers: 'العملاء', offers: 'العروض', suppliers: 'الموردين', appointments: 'المواعيد', reports: 'التقارير' };
const STATUS = { pending: 'معلق', accepted: 'مقبول', rejected: 'مرفوض' };
const TITLES = { dashboard: 'الرئيسية', customers: 'العملاء', offers: 'العروض', appointments: 'المواعيد', suppliers: 'الموردين', reports: 'التقارير', users: 'المستخدمين والصلاحيات' };

function can(mod, act) { return ME && (ME.role === 'admin' || (ME.perms[mod] && ME.perms[mod][act])); }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function egp(n) { return (Number(n) || 0).toLocaleString('ar-EG') + ' ج.م'; }
function fmtDate(iso) { if (!iso) return ''; return new Date(iso).toLocaleString('ar-EG', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); }
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2500); }

async function api(path, opts = {}) {
  const r = await fetch(path, {
    method: opts.method || 'GET',
    headers: { 'X-Requested-With': 'fetch', ...(opts.body ? { 'Content-Type': 'application/json' } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    credentials: 'same-origin',
  });
  if (r.status === 401) { showLogin(); throw new Error('unauthorized'); }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) { toast(data.error || 'حصل خطأ'); throw new Error(data.error || r.status); }
  return data;
}

/* ---------- views ---------- */
function show(id) { ['#login-view', '#changepw-view', '#app-view'].forEach(v => $(v).classList.add('hidden')); $(id).classList.remove('hidden'); }
function showLogin() { ME = null; show('#login-view'); }

function applyPerms() {
  $('#who').textContent = ME.name + (ME.role === 'admin' ? ' (مدير)' : '');
  $('#more-reports').style.display = can('reports', 'view') ? '' : 'none';
  $('#more-users').style.display = ME.role === 'admin' ? '' : 'none';
  const map = { customers: 'customers', offers: 'offers', appointments: 'appointments' };
  $$('#bottomnav .nav-btn').forEach(b => {
    const m = map[b.dataset.nav];
    b.style.display = (m && !can(m, 'view')) ? 'none' : '';
  });
}

function nav(page) {
  if (page === 'more') { $('#more-sheet').classList.remove('hidden'); return; }
  $('#more-sheet').classList.add('hidden');
  if (page === 'reports' && !can('reports', 'view')) return;
  if (page === 'users' && ME.role !== 'admin') return;
  $$('#bottomnav .nav-btn').forEach(b => b.classList.toggle('active', b.dataset.nav === page));
  $$('.page').forEach(p => p.classList.add('hidden'));
  $('#page-' + page).classList.remove('hidden');
  $('#page-title').textContent = TITLES[page];
  ({ dashboard: renderDashboard, customers: renderCustomers, offers: renderOffers,
     appointments: renderAppointments, suppliers: renderSuppliers, reports: renderReports, users: renderUsers }[page] || (() => {}))();
  loadReminders();
}

/* ---------- modal ---------- */
function openModal(title, html) { $('#modal-title').textContent = title; $('#modal-body').innerHTML = html; $('#modal').classList.remove('hidden'); }
function closeModal() { $('#modal').classList.add('hidden'); }
$('#modal-close').onclick = closeModal;
$('#modal').addEventListener('click', e => { if (e.target.id === 'modal') closeModal(); });

/* ---------- dashboard ---------- */
async function renderDashboard() {
  const el = $('#page-dashboard');
  el.innerHTML = '<div class="empty">...جاري التحميل</div>';
  const d = await api('/api/dashboard');
  let html = '<div class="cards">';
  if (d.customers !== undefined) html += `<div class="stat blue"><div class="n">${d.customers}</div><div class="l">عميل</div></div>`;
  if (d.offers) {
    const p = d.offers.find(o => o.status === 'pending') || { n: 0, total: 0 };
    const a = d.offers.find(o => o.status === 'accepted') || { n: 0, total: 0 };
    html += `<div class="stat amber"><div class="n">${p.n}</div><div class="l">عرض معلق (${egp(p.total)})</div></div>`;
    html += `<div class="stat green"><div class="n">${egp(a.total)}</div><div class="l">عروض مقبولة</div></div>`;
  }
  if (d.suppliers !== undefined) html += `<div class="stat"><div class="n">${d.suppliers}</div><div class="l">مورد</div></div>`;
  html += '</div>';

  if (d.today) {
    html += '<div class="panel"><h3>📅 المواعيد القريبة</h3>';
    html += d.today.length ? d.today.map(a => `
      <div class="row-item"><div><div class="t">${esc(a.title)}</div>
      <div class="s">${fmtDate(a.appointment_at)}${a.customer_name ? ' • ' + esc(a.customer_name) : ''}</div></div></div>`).join('')
      : '<div class="empty">مفيش مواعيد قريبة</div>';
    html += '</div>';
  }
  if (d.recent_offers) {
    html += '<div class="panel"><h3>💰 آخر العروض</h3>';
    html += d.recent_offers.length ? d.recent_offers.map(o => `
      <div class="row-item"><div><div class="t">${esc(o.title)}</div>
      <div class="s">${esc(o.customer_name || '')} • ${egp(o.amount)}</div></div>
      <span class="badge ${o.status}">${STATUS[o.status]}</span></div>`).join('')
      : '<div class="empty">مفيش عروض لسه</div>';
    html += '</div>';
  }
  if (d.recent_activity && d.recent_activity.length) {
    const act = { create: 'أضاف', update: 'عدّل', delete: 'حذف', login: 'سجّل دخول', 'reset-password': 'صفّر كلمة سر' };
    const ent = { customers: 'عميل', offers: 'عرض', suppliers: 'مورد', appointments: 'معاد', user: 'مستخدم' };
    html += '<div class="panel"><h3>🕓 آخر النشاطات</h3>' + d.recent_activity.map(a => `
      <div class="row-item"><div class="s">${esc(a.user_name || '؟')} ${act[a.action] || a.action} ${ent[a.entity] || a.entity}${a.details ? ': ' + esc(a.details) : ''} • ${fmtDate(a.created_at + 'Z')}</div></div>`).join('') + '</div>';
  }
  el.innerHTML = html;
}

/* ---------- generic list page ---------- */
function listPage(mod, rows, rowHtml, addLabel) {
  const edit = can(mod, 'edit');
  return `
    <div class="toolbar"><h2>${MODULES[mod]}</h2>
      ${edit ? `<button class="btn primary sm" style="width:auto" id="btn-add">＋ ${addLabel}</button>` : ''}</div>
    <div class="search-row"><input id="search" placeholder="ابحث..."></div>
    <div class="panel" id="list">${rows.length ? rows.map(rowHtml).join('') : '<div class="empty">مفيش بيانات لسه</div>'}</div>`;
}

async function renderCustomers() {
  const el = $('#page-customers');
  const { customers } = await api('/api/customers');
  CUSTOMERS_CACHE = customers;
  const edit = can('customers', 'edit');
  el.innerHTML = listPage('customers', customers, c => `
    <div class="row-item" data-id="${c.id}">
      <div><div class="t">${esc(c.name)}</div>
      <div class="s">${esc(c.phone)}${c.company ? ' • ' + esc(c.company) : ''}${c.area ? ' • ' + esc(c.area) : ''}</div></div>
      ${edit ? `<div class="row-actions"><button class="btn sm act-edit">✏️</button><button class="btn sm red act-del">🗑</button></div>` : ''}
    </div>`, 'عميل جديد');
  bindSearch(el, customers, () => renderCustomers());
  if (edit) {
    $('#btn-add').onclick = () => customerForm();
    el.querySelectorAll('.act-edit').forEach(b => b.onclick = e => customerForm(customers.find(c => c.id == e.target.closest('.row-item').dataset.id)));
    el.querySelectorAll('.act-del').forEach(b => b.onclick = async e => {
      const id = e.target.closest('.row-item').dataset.id;
      if (confirm('متأكد إنك عايز تحذف العميل ده؟')) { await api('/api/customers/' + id, { method: 'DELETE' }); toast('اتحذف'); renderCustomers(); }
    });
  }
}
function customerForm(c) {
  openModal(c ? 'تعديل عميل' : 'عميل جديد', `
    <form id="f">
      <label>الاسم<input name="name" value="${esc(c?.name || '')}" required></label>
      <label>التليفون<input name="phone" value="${esc(c?.phone || '')}"></label>
      <label>الشركة<input name="company" value="${esc(c?.company || '')}"></label>
      <label>المنطقة<input name="area" value="${esc(c?.area || '')}"></label>
      <label>ملاحظات<textarea name="notes">${esc(c?.notes || '')}</textarea></label>
      <button class="btn primary">حفظ</button>
    </form>`);
  $('#f').onsubmit = async e => {
    e.preventDefault();
    const b = Object.fromEntries(new FormData(e.target));
    await api(c ? '/api/customers/' + c.id : '/api/customers', { method: c ? 'PUT' : 'POST', body: b });
    closeModal(); toast('اتحفظ ✅'); renderCustomers();
  };
}

async function renderOffers() {
  const el = $('#page-offers');
  const [{ offers }, cust] = await Promise.all([api('/api/offers'), can('customers', 'view') ? api('/api/customers') : Promise.resolve({ customers: [] })]);
  CUSTOMERS_CACHE = cust.customers;
  const edit = can('offers', 'edit');
  el.innerHTML = listPage('offers', offers, o => `
    <div class="row-item" data-id="${o.id}">
      <div><div class="t">${esc(o.title)}</div>
      <div class="s">${esc(o.customer_name || '')} • ${egp(o.amount)} • ${esc(o.offer_date)}</div></div>
      <div class="row-actions"><span class="badge ${o.status}">${STATUS[o.status]}</span>
      ${edit ? `<button class="btn sm act-edit">✏️</button><button class="btn sm red act-del">🗑</button>` : ''}</div>
    </div>`, 'عرض جديد');
  $('#search').oninput = e => {
    const s = e.target.value.trim();
    $$('#list .row-item').forEach(r => {
      const o = offers.find(x => x.id == r.dataset.id);
      r.style.display = (!s || (o.title + (o.customer_name || '')).includes(s)) ? '' : 'none';
    });
  };
  if (edit) {
    $('#btn-add').onclick = () => offerForm();
    el.querySelectorAll('.act-edit').forEach(b => b.onclick = e => offerForm(offers.find(o => o.id == e.target.closest('.row-item').dataset.id)));
    el.querySelectorAll('.act-del').forEach(b => b.onclick = async e => {
      const id = e.target.closest('.row-item').dataset.id;
      if (confirm('متأكد إنك عايز تحذف العرض ده؟')) { await api('/api/offers/' + id, { method: 'DELETE' }); toast('اتحذف'); renderOffers(); }
    });
  }
}
function offerForm(o) {
  const opts = CUSTOMERS_CACHE.map(c => `<option value="${c.id}" ${o?.customer_id == c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
  openModal(o ? 'تعديل عرض' : 'عرض جديد', `
    <form id="f">
      <label>عنوان العرض<input name="title" value="${esc(o?.title || '')}" required></label>
      <label>العميل<select name="customer_id"><option value="">— بدون —</option>${opts}</select></label>
      <label>المبلغ (ج.م)<input name="amount" type="number" min="0" step="any" value="${o?.amount ?? ''}"></label>
      <label>الحالة<select name="status">${Object.entries(STATUS).map(([k, v]) => `<option value="${k}" ${o?.status === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
      <label>التاريخ<input name="offer_date" type="date" value="${esc(o?.offer_date || new Date().toISOString().slice(0, 10))}"></label>
      <label>ملاحظات<textarea name="notes">${esc(o?.notes || '')}</textarea></label>
      <button class="btn primary">حفظ</button>
    </form>`);
  $('#f').onsubmit = async e => {
    e.preventDefault();
    const b = Object.fromEntries(new FormData(e.target));
    b.amount = Number(b.amount) || 0;
    await api(o ? '/api/offers/' + o.id : '/api/offers', { method: o ? 'PUT' : 'POST', body: b });
    closeModal(); toast('اتحفظ ✅'); renderOffers();
  };
}

async function renderAppointments() {
  const el = $('#page-appointments');
  const [{ appointments }, cust] = await Promise.all([api('/api/appointments'), can('customers', 'view') ? api('/api/customers') : Promise.resolve({ customers: [] })]);
  CUSTOMERS_CACHE = cust.customers;
  const edit = can('appointments', 'edit');
  const now = Date.now();
  el.innerHTML = `<div class="toolbar"><h2>المواعيد</h2>
      ${edit ? `<button class="btn primary sm" style="width:auto" id="btn-add">＋ معاد جديد</button>` : ''}</div>
    <div class="panel" id="list">${appointments.length ? appointments.map(a => {
      const over = !a.done && new Date(a.appointment_at).getTime() < now;
      return `<div class="row-item" data-id="${a.id}">
        <div><div class="t">${a.done ? '✅ ' : over ? '🔴 ' : ''}${esc(a.title)}</div>
        <div class="s">${fmtDate(a.appointment_at)}${a.customer_name ? ' • ' + esc(a.customer_name) : ''}${a.notes ? ' • ' + esc(a.notes) : ''}</div></div>
        ${edit ? `<div class="row-actions">
          ${!a.done ? `<button class="btn sm green act-done">تم</button>` : ''}
          <button class="btn sm act-edit">✏️</button><button class="btn sm red act-del">🗑</button></div>` : ''}
      </div>`; }).join('') : '<div class="empty">مفيش مواعيد</div>'}</div>`;
  if (edit) {
    $('#btn-add').onclick = () => apptForm();
    el.querySelectorAll('.act-edit').forEach(b => b.onclick = e => apptForm(appointments.find(a => a.id == e.target.closest('.row-item').dataset.id)));
    el.querySelectorAll('.act-done').forEach(b => b.onclick = async e => {
      const id = e.target.closest('.row-item').dataset.id;
      await api('/api/appointments/' + id, { method: 'PUT', body: { done: true } }); toast('اتعلم كتم ✅'); renderAppointments();
    });
    el.querySelectorAll('.act-del').forEach(b => b.onclick = async e => {
      const id = e.target.closest('.row-item').dataset.id;
      if (confirm('تحذف المعاد ده؟')) { await api('/api/appointments/' + id, { method: 'DELETE' }); toast('اتحذف'); renderAppointments(); }
    });
  }
}
function apptForm(a) {
  const opts = CUSTOMERS_CACHE.map(c => `<option value="${c.id}" ${a?.customer_id == c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
  const dt = a ? new Date(a.appointment_at) : new Date(Date.now() + 864e5);
  dt.setMinutes(dt.getMinutes() - dt.getTimezoneOffset());
  openModal(a ? 'تعديل معاد' : 'معاد جديد', `
    <form id="f">
      <label>العنوان<input name="title" value="${esc(a?.title || '')}" required></label>
      <label>العميل (اختياري)<select name="customer_id"><option value="">— بدون —</option>${opts}</select></label>
      <label>التاريخ والوقت<input name="appointment_at" type="datetime-local" value="${dt.toISOString().slice(0, 16)}" required></label>
      <label>ملاحظات<textarea name="notes">${esc(a?.notes || '')}</textarea></label>
      <button class="btn primary">حفظ</button>
    </form>`);
  $('#f').onsubmit = async e => {
    e.preventDefault();
    const b = Object.fromEntries(new FormData(e.target));
    b.appointment_at = new Date(b.appointment_at).toISOString();
    await api(a ? '/api/appointments/' + a.id : '/api/appointments', { method: a ? 'PUT' : 'POST', body: b });
    closeModal(); toast('اتحفظ ✅'); renderAppointments();
  };
}

async function renderSuppliers() {
  const el = $('#page-suppliers');
  const { suppliers } = await api('/api/suppliers');
  const edit = can('suppliers', 'edit');
  el.innerHTML = listPage('suppliers', suppliers, s => `
    <div class="row-item" data-id="${s.id}">
      <div><div class="t">${esc(s.name)}</div>
      <div class="s">${esc(s.phone)}${s.company ? ' • ' + esc(s.company) : ''}${s.category ? ' • ' + esc(s.category) : ''}</div></div>
      ${edit ? `<div class="row-actions"><button class="btn sm act-edit">✏️</button><button class="btn sm red act-del">🗑</button></div>` : ''}
    </div>`, 'مورد جديد');
  bindSearch(el, suppliers, () => renderSuppliers());
  if (edit) {
    $('#btn-add').onclick = () => supForm();
    el.querySelectorAll('.act-edit').forEach(b => b.onclick = e => supForm(suppliers.find(s => s.id == e.target.closest('.row-item').dataset.id)));
    el.querySelectorAll('.act-del').forEach(b => b.onclick = async e => {
      const id = e.target.closest('.row-item').dataset.id;
      if (confirm('تحذف المورد ده؟')) { await api('/api/suppliers/' + id, { method: 'DELETE' }); toast('اتحذف'); renderSuppliers(); }
    });
  }
}
function bindSearch(el, rows, rerender) {
  $('#search').oninput = e => {
    const s = e.target.value.trim();
    $$('#list .row-item').forEach(r => {
      r.style.display = (!s || r.textContent.includes(s)) ? '' : 'none';
    });
  };
}
function supForm(s) {
  openModal(s ? 'تعديل مورد' : 'مورد جديد', `
    <form id="f">
      <label>الاسم<input name="name" value="${esc(s?.name || '')}" required></label>
      <label>التليفون<input name="phone" value="${esc(s?.phone || '')}"></label>
      <label>الشركة<input name="company" value="${esc(s?.company || '')}"></label>
      <label>التصنيف<input name="category" value="${esc(s?.category || '')}" placeholder="مثال: كاميرات، كابلات"></label>
      <label>ملاحظات<textarea name="notes">${esc(s?.notes || '')}</textarea></label>
      <button class="btn primary">حفظ</button>
    </form>`);
  $('#f').onsubmit = async e => {
    e.preventDefault();
    const b = Object.fromEntries(new FormData(e.target));
    await api(s ? '/api/suppliers/' + s.id : '/api/suppliers', { method: s ? 'PUT' : 'POST', body: b });
    closeModal(); toast('اتحفظ ✅'); renderSuppliers();
  };
}

/* ---------- reports ---------- */
async function renderReports() {
  const el = $('#page-reports');
  const today = new Date(), first = new Date(today.getFullYear(), today.getMonth(), 1);
  el.innerHTML = `
    <div class="toolbar"><h2>التقارير</h2></div>
    <div class="panel">
      <div class="rep-controls">
        <label>من<input type="date" id="rep-from" value="${first.toISOString().slice(0, 10)}"></label>
        <label>إلى<input type="date" id="rep-to" value="${today.toISOString().slice(0, 10)}"></label>
        <button class="btn primary sm" style="width:auto;align-self:end" id="rep-run">عرض</button>
      </div>
      <div id="rep-out"></div>
    </div>
    <div class="panel"><h3>⬇️ تصدير ملفات Excel (CSV)</h3>
      <div style="display:flex;gap:.5rem;flex-wrap:wrap">
        <a class="btn sm" href="/api/reports/customers.csv">العملاء</a>
        <a class="btn sm" href="/api/reports/offers.csv">العروض</a>
        <a class="btn sm" href="/api/reports/suppliers.csv">الموردين</a>
        <a class="btn sm" href="/api/reports/appointments.csv">المواعيد</a>
      </div>
    </div>`;
  $('#rep-run').onclick = runReport;
  runReport();
  async function runReport() {
    const d = await api(`/api/reports/summary?from=${$('#rep-from').value}&to=${$('#rep-to').value}`);
    const g = st => d.offers.find(o => o.status === st) || { n: 0, total: 0 };
    const colors = { pending: '#f59e0b', accepted: '#16a34a', rejected: '#dc2626' };
    const mx = Math.max(1, ...d.offers.map(o => o.total));
    $('#rep-out').innerHTML = `
      <h3 style="font-size:.9rem;margin-bottom:.6rem">العروض في الفترة</h3>
      ${d.offers.map(o => `<div class="bar-wrap"><span class="bar-txt">${STATUS[o.status]} (${o.n})</span>
        <div class="bar" style="width:${Math.round(o.total / mx * 100)}%;background:${colors[o.status]}"></div>
        <span>${egp(o.total)}</span></div>`).join('') || '<div class="empty">مفيش عروض في الفترة دي</div>'}
      <div class="kv" style="margin:.8rem 0">المواعيد في الفترة: ${d.appointments.n || 0} (تم منها ${d.appointments.done || 0})</div>
      ${d.byCustomer.length ? `<h3 style="font-size:.9rem;margin:.6rem 0">أعلى العملاء (عروض مقبولة وغيرها)</h3>
      <table class="rep"><tr><th>العميل</th><th>عدد العروض</th><th>الإجمالي</th></tr>
      ${d.byCustomer.map(c => `<tr><td>${esc(c.name)}</td><td>${c.n}</td><td>${egp(c.total)}</td></tr>`).join('')}</table>` : ''}`;
  }
}

/* ---------- users ---------- */
async function renderUsers() {
  const el = $('#page-users');
  const { users } = await api('/api/users');
  el.innerHTML = `
    <div class="toolbar"><h2>المستخدمين</h2>
      <button class="btn primary sm" style="width:auto" id="btn-add">＋ مستخدم جديد</button></div>
    <div class="panel">${users.map(u => `
      <div class="row-item" data-id="${u.id}">
        <div><div class="t">${esc(u.name)} ${u.active ? '' : '<span class="badge off">موقوف</span>'}</div>
        <div class="s">@${esc(u.username)} • <span class="badge role">${u.role === 'admin' ? 'مدير' : 'موظف'}</span></div></div>
        <div class="row-actions"><button class="btn sm act-edit">✏️</button>
        <button class="btn sm act-pw" title="تصفير كلمة السر">🔑</button></div>
      </div>`).join('')}</div>`;
  $('#btn-add').onclick = () => userForm();
  el.querySelectorAll('.act-edit').forEach(b => b.onclick = e => userForm(users.find(u => u.id == e.target.closest('.row-item').dataset.id)));
  el.querySelectorAll('.act-pw').forEach(b => b.onclick = async e => {
    const id = e.target.closest('.row-item').dataset.id;
    if (!confirm('هتعمل كلمة سر مؤقتة جديدة للمستخدم ده والقديمة هتبطل. كمّل؟')) return;
    const r = await api(`/api/users/${id}/reset-password`, { method: 'POST' });
    openModal('كلمة السر المؤقتة', `<p>ادّي كلمة السر دي للمستخدم (هيظهر مطلوب يغيّرها أول ما يدخل):</p>
      <p style="text-align:center;font-size:1.5rem;font-weight:800;letter-spacing:.15em;margin:1rem 0;direction:ltr">${r.temp_password}</p>
      <button class="btn primary" onclick="document.getElementById('modal').classList.add('hidden')">تمام</button>`);
  });
}
function userForm(u) {
  const p = u?.perms || {};
  const g = (m, a) => (u?.role === 'admin') || (p[m] && p[m][a]) ? 'checked' : '';
  const rows = [['customers', 'العملاء'], ['offers', 'العروض'], ['suppliers', 'الموردين'], ['appointments', 'المواعيد']];
  openModal(u ? 'تعديل مستخدم' : 'مستخدم جديد', `
    <form id="f">
      <label>الاسم<input name="name" value="${esc(u?.name || '')}" required></label>
      ${u ? '' : '<label>اسم المستخدم (إنجليزي)<input name="username" dir="ltr" required></label>'}
      <label>الدور<select name="role">
        <option value="staff" ${u?.role !== 'admin' ? 'selected' : ''}>موظف (حسب الصلاحيات تحت)</option>
        <option value="admin" ${u?.role === 'admin' ? 'selected' : ''}>مدير (كل الصلاحيات)</option>
      </select></label>
      <div class="perm-grid">
        <span></span><span class="head">يشوف</span><span class="head">يعدّل</span>
        ${rows.map(([m, l]) => `<span>${l}</span>
          <input type="checkbox" name="p_${m}_view" ${g(m, 'view')}>
          <input type="checkbox" name="p_${m}_edit" ${g(m, 'edit')}>`).join('')}
        <span>التقارير</span><input type="checkbox" name="p_reports_view" ${g('reports', 'view')}><span></span>
      </div>
      ${u ? `<label style="display:flex;align-items:center;gap:.5rem"><input type="checkbox" name="active" style="width:auto;margin:0" ${u.active ? 'checked' : ''}> حساب شغال</label>` : ''}
      <button class="btn primary">${u ? 'حفظ' : 'إنشاء'}</button>
    </form>`);
  $('#f').onsubmit = async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const perms = {};
    for (const m of ['customers', 'offers', 'suppliers', 'appointments'])
      perms[m] = { view: !!fd.get(`p_${m}_view`), edit: !!fd.get(`p_${m}_edit`) };
    perms.reports = { view: !!fd.get('p_reports_view') };
    const body = { name: fd.get('name'), role: fd.get('role'), perms };
    if (u) {
      body.active = !!fd.get('active');
      await api('/api/users/' + u.id, { method: 'PUT', body });
      closeModal(); toast('اتحفظ ✅'); renderUsers();
    } else {
      body.username = fd.get('username');
      const r = await api('/api/users', { method: 'POST', body });
      openModal('تم إنشاء المستخدم ✅', `<p>بيانات الدخول للمستخدم الجديد:</p>
        <p style="margin:.8rem 0">اسم المستخدم: <b dir="ltr">${esc(r.user.username)}</b><br>
        كلمة سر مؤقتة: <b dir="ltr" style="font-size:1.3rem;letter-spacing:.1em">${r.temp_password}</b></p>
        <p class="muted">هيطلب منه يغيّرها أول ما يدخل.</p>
        <button class="btn primary" onclick="document.getElementById('modal').classList.add('hidden')">تمام</button>`);
      renderUsers();
    }
  };
}

/* ---------- reminders ---------- */
async function loadReminders() {
  if (!can('appointments', 'view')) return;
  try {
    const { reminders } = await api('/api/reminders');
    const bar = $('#reminders-bar');
    if (!reminders.length) { bar.classList.add('hidden'); return; }
    const over = reminders.filter(r => r.overdue).length;
    bar.textContent = `⏰ عندك ${reminders.length} معاد قريب${over ? ` (${over} فات ميعاده!)` : ''} — اضغط للعرض`;
    bar.onclick = () => nav('appointments');
    bar.classList.remove('hidden');
  } catch { }
}

/* ---------- auth flows ---------- */
$('#login-form').onsubmit = async e => {
  e.preventDefault();
  $('#login-error').textContent = '';
  try {
    const { user } = await api('/api/login', { method: 'POST', body: { username: $('#login-username').value, password: $('#login-password').value } });
    boot(user);
  } catch (err) {
    $('#login-error').textContent = 'بيانات الدخول غير صحيحة أو المحاولات كتير';
  }
};
$('#changepw-form').onsubmit = async e => {
  e.preventDefault();
  $('#cp-error').textContent = '';
  try {
    await api('/api/me/password', { method: 'POST', body: { current: $('#cp-current').value, next: $('#cp-next').value } });
    ME.must_change_password = false;
    toast('كلمة السر اتغيّرت ✅');
    boot(ME);
  } catch (err) { $('#cp-error').textContent = err.message === 'unauthorized' ? '' : 'اتأكد من البيانات (الجديدة ٨ حروف على الأقل)'; }
};

function boot(user) {
  ME = user;
  if (ME.must_change_password) { $('#cp-current').value = ''; $('#cp-next').value = ''; show('#changepw-view'); return; }
  show('#app-view');
  applyPerms();
  nav(can('customers', 'view') || can('offers', 'view') || can('appointments', 'view') ? 'dashboard' :
    (can('customers', 'view') ? 'customers' : can('offers', 'view') ? 'offers' : can('appointments', 'view') ? 'appointments' : 'suppliers'));
}

$('#more-sheet').addEventListener('click', e => { if (e.target.id === 'more-sheet') $('#more-sheet').classList.add('hidden'); });
$$('.nav-btn, .sheet-item[data-nav]').forEach(b => b.addEventListener('click', () => nav(b.dataset.nav)));
$('#more-logout').onclick = async () => { await api('/api/logout', { method: 'POST' }).catch(() => { }); showLogin(); };
$('#btn-lock').onclick = async () => { await api('/api/logout', { method: 'POST' }).catch(() => { }); showLogin(); };
$('#more-password').onclick = () => { $('#more-sheet').classList.add('hidden'); $('#cp-current').value = ''; $('#cp-next').value = ''; show('#changepw-view'); };

/* ---------- init ---------- */
(async () => {
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => { });
  try { const { user } = await api('/api/me'); boot(user); } catch { showLogin(); }
})();
