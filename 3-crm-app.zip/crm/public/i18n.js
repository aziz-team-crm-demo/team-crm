/* Language layer: Arabic (default, RTL) and English (LTR). Choice is saved in this browser. */
const LANG = (localStorage.getItem('crm_lang') === 'en') ? 'en' : 'ar';
document.documentElement.lang = LANG;
document.documentElement.dir = LANG === 'en' ? 'ltr' : 'rtl';

const EN = {
  'نظام إدارة العملاء': 'Customer Management System',
  'سجّل دخولك للمتابعة': 'Sign in to continue',
  'اسم المستخدم': 'Username',
  'كلمة السر': 'Password',
  'دخول': 'Sign in',
  'غيّر كلمة السر': 'Change password',
  'لازم تغيّر كلمة السر المؤقتة قبل المتابعة': 'You must change your temporary password before continuing',
  'كلمة السر الحالية': 'Current password',
  'كلمة السر الجديدة (٨ حروف على الأقل)': 'New password (at least 8 characters)',
  'حفظ ومتابعة': 'Save and continue',
  'الرئيسية': 'Home', 'العملاء': 'Customers', 'العروض': 'Offers', 'المواعيد': 'Appointments',
  'الموردين': 'Suppliers', 'المزيد': 'More', 'التقارير': 'Reports',
  'المستخدمين والصلاحيات': 'Users & permissions', 'المستخدمين': 'Users',
  'قفل / خروج': 'Lock / sign out',
  'الموردين': 'Suppliers',
  'تغيير كلمة السر': 'Change password',
  'تسجيل خروج': 'Sign out',
  'معلق': 'Pending', 'مقبول': 'Accepted', 'مرفوض': 'Rejected',
  'مدير': 'Admin', 'موظف': 'Staff', ' (مدير)': ' (Admin)',
  'حصل خطأ': 'Something went wrong',
  '...جاري التحميل': 'Loading...',
  'عميل': 'customers', 'مورد': 'suppliers',
  'عروض مقبولة': 'Accepted offers',
  'المواعيد القريبة': 'Upcoming appointments',
  'مفيش مواعيد قريبة': 'No upcoming appointments',
  'آخر العروض': 'Latest offers',
  'مفيش عروض لسه': 'No offers yet',
  'آخر النشاطات': 'Recent activity',
  'أضاف': 'added', 'عدّل': 'edited', 'حذف': 'deleted', 'سجّل دخول': 'signed in', 'صفّر كلمة سر': 'reset the password of',
  'معاد': 'appointment', 'مستخدم': 'user',
  'ابحث...': 'Search...',
  'مفيش بيانات لسه': 'No data yet',
  'عميل جديد': 'New customer', 'عرض جديد': 'New offer', 'مورد جديد': 'New supplier',
  'معاد جديد': 'New appointment', 'مستخدم جديد': 'New user',
  'تعديل عميل': 'Edit customer', 'تعديل عرض': 'Edit offer', 'تعديل معاد': 'Edit appointment',
  'تعديل مورد': 'Edit supplier', 'تعديل مستخدم': 'Edit user',
  'متأكد إنك عايز تحذف العميل ده؟': 'Are you sure you want to delete this customer?',
  'متأكد إنك عايز تحذف العرض ده؟': 'Are you sure you want to delete this offer?',
  'تحذف المعاد ده؟': 'Delete this appointment?',
  'تحذف المورد ده؟': 'Delete this supplier?',
  'اتحذف': 'Deleted', 'اتحفظ ✅': 'Saved ✅', 'اتعلم كتم ✅': 'Marked as done ✅',
  'الاسم': 'Name', 'التليفون': 'Phone', 'الشركة': 'Company', 'المنطقة': 'Area', 'ملاحظات': 'Notes',
  'حفظ': 'Save', 'إنشاء': 'Create', 'تم': 'Done', 'تمام': 'OK',
  'عنوان العرض': 'Offer title', 'العميل': 'Customer', '— بدون —': '— None —',
  'المبلغ (ج.م)': 'Amount (EGP)', 'الحالة': 'Status', 'التاريخ': 'Date',
  'العنوان': 'Title', 'العميل (اختياري)': 'Customer (optional)', 'التاريخ والوقت': 'Date and time',
  'التصنيف': 'Category', 'مثال: كاميرات، كابلات': 'e.g. cameras, cables',
  'مفيش مواعيد': 'No appointments',
  'من': 'From', 'إلى': 'To', 'عرض': 'Show',
  'تصدير ملفات Excel (CSV)': 'Export Excel files (CSV)',
  'العروض في الفترة': 'Offers in the period',
  'مفيش عروض في الفترة دي': 'No offers in this period',
  'أعلى العملاء (عروض مقبولة وغيرها)': 'Top customers (all offers)',
  'عدد العروض': 'Offers', 'الإجمالي': 'Total',
  'موقوف': 'Suspended',
  'تصفير كلمة السر': 'Reset password',
  'هتعمل كلمة سر مؤقتة جديدة للمستخدم ده والقديمة هتبطل. كمّل؟': 'This creates a new temporary password for this user and the old one stops working. Continue?',
  'كلمة السر المؤقتة': 'Temporary password',
  'ادّي كلمة السر دي للمستخدم (هيظهر مطلوب يغيّرها أول ما يدخل):': 'Give this password to the user (they will be asked to change it on first sign-in):',
  'الاسم': 'Name',
  'اسم المستخدم (إنجليزي)': 'Username (English letters)',
  'الدور': 'Role',
  'موظف (حسب الصلاحيات تحت)': 'Staff (per the permissions below)',
  'مدير (كل الصلاحيات)': 'Admin (all permissions)',
  'يشوف': 'View', 'يعدّل': 'Edit',
  'حساب شغال': 'Active account',
  'تم إنشاء المستخدم ✅': 'User created ✅',
  'بيانات الدخول للمستخدم الجديد:': 'Sign-in details for the new user:',
  'كلمة سر مؤقتة:': 'Temporary password:',
  'هيطلب منه يغيّرها أول ما يدخل.': 'They will be asked to change it on first sign-in.',
  'بيانات الدخول غير صحيحة أو المحاولات كتير': 'Wrong sign-in details, or too many attempts',
  'كلمة السر اتغيّرت ✅': 'Password changed ✅',
  'اتأكد من البيانات (الجديدة ٨ حروف على الأقل)': 'Check the details (new password must be at least 8 characters)',
  // server messages
  'محاولات كتير. جرب بعد ٥ دقايق': 'Too many attempts. Try again in 5 minutes',
  'بيانات الدخول غير صحيحة': 'Wrong sign-in details',
  'كلمة السر الحالية غلط': 'Current password is wrong',
  'كلمة السر لازم ٨ حروف على الأقل': 'Password must be at least 8 characters',
  'الاسم واسم المستخدم مطلوبين': 'Name and username are required',
  'اسم المستخدم: حروف إنجليزية وأرقام فقط (٣ على الأقل)': 'Username: English letters and numbers only (3 or more)',
  'اسم المستخدم موجود قبل كده': 'This username already exists',
  'مش موجود': 'Not found',
  'مينفعش تشيل صلاحيتك أو توقف نفسك': 'You cannot remove your own admin rights or suspend yourself',
  'البيانات ناقصة': 'Missing data',
  'عنوان العرض مطلوب': 'Offer title is required',
  'العنوان والمعاد مطلوبين': 'Title and date are required',
  'معاد غير صحيح': 'Invalid date',
};
const EN_KEYS = Object.keys(EN).filter(k => k.length >= 5).sort((a, b) => b.length - a.length);

function tr(s) { return LANG === 'en' && EN[s] ? EN[s] : s; }

function trText(s) {
  const t = s.trim();
  if (!t || !/[\u0600-\u06FF]/.test(s)) return s;
  if (EN[t]) return s.replace(t, EN[t]);
  let m;
  if ((m = t.match(/^⏰ عندك (\d+) معاد قريب(?: \((\d+) فات ميعاده!\))? — اضغط للعرض$/)))
    return `⏰ You have ${m[1]} upcoming appointment(s)${m[2] ? ` (${m[2]} overdue!)` : ''} — tap to view`;
  if ((m = t.match(/^المواعيد في الفترة: (\d+) \(تم منها (\d+)\)$/))) return `Appointments in the period: ${m[1]} (${m[2]} done)`;
  if ((m = t.match(/^عرض معلق \((.*)\)$/))) return `Pending offers (${m[1]})`;
  if ((m = t.match(/^(معلق|مقبول|مرفوض) \((\d+)\)$/))) return `${EN[m[1]]} (${m[2]})`;
  let out = s;
  for (const k of EN_KEYS) if (out.includes(k)) out = out.split(k).join(EN[k]);
  return out;
}

function trNode(root) {
  if (LANG !== 'en') return;
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = []; while (w.nextNode()) nodes.push(w.currentNode);
  for (const n of nodes) { const v = trText(n.nodeValue); if (v !== n.nodeValue) n.nodeValue = v; }
  if (root.querySelectorAll) root.querySelectorAll('[placeholder],[title]').forEach(el => {
    for (const a of ['placeholder', 'title']) if (el.hasAttribute(a)) { const v = trText(el.getAttribute(a)); if (v !== el.getAttribute(a)) el.setAttribute(a, v); }
  });
}

if (LANG === 'en') {
  document.title = EN['نظام إدارة العملاء'];
  const _confirm = window.confirm.bind(window);
  window.confirm = m => _confirm(trText(m));
  const mo = new MutationObserver(muts => {
    mo.disconnect();
    for (const m of muts) {
      if (m.type === 'characterData') { const v = trText(m.target.nodeValue); if (v !== m.target.nodeValue) m.target.nodeValue = v; }
      else m.addedNodes.forEach(n => { if (n.nodeType === 1) trNode(n); else if (n.nodeType === 3) { const v = trText(n.nodeValue); if (v !== n.nodeValue) n.nodeValue = v; } });
    }
    mo.observe(document.body, { childList: true, subtree: true, characterData: true });
  });
  document.addEventListener('DOMContentLoaded', () => { trNode(document.body); mo.observe(document.body, { childList: true, subtree: true, characterData: true }); });
}

function toggleLang() { localStorage.setItem('crm_lang', LANG === 'en' ? 'ar' : 'en'); location.reload(); }
document.addEventListener('click', e => { if (e.target.closest && e.target.closest('.lang-btn')) toggleLang(); });
