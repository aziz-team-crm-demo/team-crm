// CRM server: Express + node:sqlite, session auth, roles & permissions.
const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const { DatabaseSync } = require('node:sqlite');

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, 'crm.db'));

db.exec(`
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'staff',
  perms TEXT NOT NULL DEFAULT '{}',
  active INTEGER NOT NULL DEFAULT 1,
  must_change_password INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT DEFAULT '',
  company TEXT DEFAULT '',
  area TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS offers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  amount REAL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  offer_date TEXT NOT NULL DEFAULT (date('now')),
  notes TEXT DEFAULT '',
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT DEFAULT '',
  company TEXT DEFAULT '',
  category TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS appointments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  appointment_at TEXT NOT NULL,
  notes TEXT DEFAULT '',
  done INTEGER NOT NULL DEFAULT 0,
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS activity (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id INTEGER,
  details TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

// ---------- helpers ----------
const q = {
  get: (sql, ...p) => db.prepare(sql).get(...p),
  all: (sql, ...p) => db.prepare(sql).all(...p),
  run: (sql, ...p) => db.prepare(sql).run(...p),
};

const DEFAULT_PERMS = {
  customers: { view: true, edit: true },
  offers: { view: true, edit: true },
  suppliers: { view: true, edit: false },
  appointments: { view: true, edit: true },
  reports: { view: false },
};

function parsePerms(u) {
  try { return JSON.parse(u.perms || '{}'); } catch { return {}; }
}
function can(user, module, action) {
  if (user.role === 'admin') return true;
  const p = parsePerms(user);
  return !!(p[module] && p[module][action]);
}
function logActivity(userId, action, entity, entityId, details) {
  q.run('INSERT INTO activity (user_id, action, entity, entity_id, details) VALUES (?,?,?,?,?)',
    userId, action, entity, entityId, (details || '').slice(0, 200));
}
function publicUser(u) {
  return { id: u.id, username: u.username, name: u.name, role: u.role,
    perms: parsePerms(u), active: !!u.active, must_change_password: !!u.must_change_password };
}

// ---------- app ----------
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
app.use((req, res, next) => {
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('X-Frame-Options', 'DENY');
  res.set('Referrer-Policy', 'same-origin');
  next();
});

// simple login rate limit: 10 tries / 5 min / IP
const tries = new Map();
function rateOk(ip) {
  const now = Date.now();
  const rec = tries.get(ip) || { n: 0, reset: now + 5 * 60e3 };
  if (now > rec.reset) { rec.n = 0; rec.reset = now + 5 * 60e3; }
  rec.n++; tries.set(ip, rec);
  return rec.n <= 10;
}

function setSession(res, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  q.run("INSERT INTO sessions (token, user_id, expires_at) VALUES (?,?,datetime('now','+30 days'))", token, userId);
  res.cookie('crm_sid', token, { httpOnly: true, sameSite: 'lax', secure: !!process.env.RENDER, maxAge: 30 * 864e5, path: '/' });
}
function auth(req, res, next) {
  const token = req.headers.cookie && req.headers.cookie.split(';').map(s => s.trim())
    .map(s => s.split('=')).find(p => p[0] === 'crm_sid');
  let user = null;
  if (token && token[1]) {
    const s = q.get("SELECT * FROM sessions WHERE token=? AND expires_at > datetime('now')", token[1]);
    if (s) user = q.get('SELECT * FROM users WHERE id=? AND active=1', s.user_id);
  }
  if (!user) return res.status(401).json({ error: 'unauthorized' });
  req.user = user;
  next();
}
function need(module, action) {
  return (req, res, next) => can(req.user, module, action) ? next() : res.status(403).json({ error: 'forbidden' });
}
// CSRF-light: mutating API calls must carry this header (SPA sets it)
app.use('/api', (req, res, next) => {
  if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && req.path !== '/login') {
    if (req.headers['x-requested-with'] !== 'fetch') return res.status(403).json({ error: 'bad request' });
  }
  next();
});

// ---------- auth ----------
app.post('/api/login', (req, res) => {
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  if (!rateOk(String(ip))) return res.status(429).json({ error: 'محاولات كتير. جرب بعد ٥ دقايق' });
  const { username, password } = req.body || {};
  const u = username && q.get('SELECT * FROM users WHERE username=? AND active=1', String(username).trim().toLowerCase());
  if (!u || !bcrypt.compareSync(String(password || ''), u.password_hash))
    return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  setSession(res, u.id);
  logActivity(u.id, 'login', 'user', u.id, '');
  res.json({ user: publicUser(u) });
});
app.post('/api/logout', auth, (req, res) => {
  const c = req.headers.cookie.match(/crm_sid=([^;]+)/);
  if (c) q.run('DELETE FROM sessions WHERE token=?', c[1]);
  res.clearCookie('crm_sid', { path: '/' });
  res.json({ ok: true });
});
app.get('/api/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));
app.post('/api/me/password', auth, (req, res) => {
  const { current, next: nw } = req.body || {};
  if (!bcrypt.compareSync(String(current || ''), req.user.password_hash))
    return res.status(400).json({ error: 'كلمة السر الحالية غلط' });
  if (String(nw || '').length < 8) return res.status(400).json({ error: 'كلمة السر لازم ٨ حروف على الأقل' });
  q.run('UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?', bcrypt.hashSync(String(nw), 10), req.user.id);
  q.run('DELETE FROM sessions WHERE user_id=?', req.user.id);
  setSession(res, req.user.id);
  res.json({ ok: true });
});

// ---------- users (admin) ----------
app.get('/api/users', auth, need('users', 'manage'), (req, res) =>
  res.json({ users: q.all('SELECT * FROM users ORDER BY id').map(publicUser) }));
app.post('/api/users', auth, need('users', 'manage'), (req, res) => {
  const { name, username, role, perms } = req.body || {};
  if (!name || !username) return res.status(400).json({ error: 'الاسم واسم المستخدم مطلوبين' });
  const un = String(username).trim().toLowerCase();
  if (!/^[a-z0-9_.-]{3,30}$/.test(un)) return res.status(400).json({ error: 'اسم المستخدم: حروف إنجليزية وأرقام فقط (٣ على الأقل)' });
  if (q.get('SELECT id FROM users WHERE username=?', un)) return res.status(400).json({ error: 'اسم المستخدم موجود قبل كده' });
  const temp = crypto.randomBytes(4).toString('hex'); // 8 chars
  const r = q.run('INSERT INTO users (username, name, password_hash, role, perms, must_change_password) VALUES (?,?,?,?,?,1)',
    un, String(name).slice(0, 80), bcrypt.hashSync(temp, 10),
    role === 'admin' ? 'admin' : 'staff', JSON.stringify(perms || DEFAULT_PERMS));
  logActivity(req.user.id, 'create', 'user', r.lastInsertRowid, un);
  res.json({ user: publicUser(q.get('SELECT * FROM users WHERE id=?', r.lastInsertRowid)), temp_password: temp });
});
app.put('/api/users/:id', auth, need('users', 'manage'), (req, res) => {
  const u = q.get('SELECT * FROM users WHERE id=?', req.params.id);
  if (!u) return res.status(404).json({ error: 'مش موجود' });
  const { name, role, perms, active } = req.body || {};
  if (u.id === req.user.id && (active === false || (role && role !== 'admin')))
    return res.status(400).json({ error: 'مينفعش تشيل صلاحيتك أو توقف نفسك' });
  q.run('UPDATE users SET name=?, role=?, perms=?, active=? WHERE id=?',
    name ? String(name).slice(0, 80) : u.name,
    role === 'admin' ? 'admin' : 'staff',
    JSON.stringify(perms || parsePerms(u)),
    active === undefined ? u.active : (active ? 1 : 0), u.id);
  if (active === false) q.run('DELETE FROM sessions WHERE user_id=?', u.id);
  logActivity(req.user.id, 'update', 'user', u.id, u.username);
  res.json({ user: publicUser(q.get('SELECT * FROM users WHERE id=?', u.id)) });
});
app.post('/api/users/:id/reset-password', auth, need('users', 'manage'), (req, res) => {
  const u = q.get('SELECT * FROM users WHERE id=?', req.params.id);
  if (!u) return res.status(404).json({ error: 'مش موجود' });
  const temp = crypto.randomBytes(4).toString('hex');
  q.run('UPDATE users SET password_hash=?, must_change_password=1 WHERE id=?', bcrypt.hashSync(temp, 10), u.id);
  q.run('DELETE FROM sessions WHERE user_id=?', u.id);
  logActivity(req.user.id, 'reset-password', 'user', u.id, u.username);
  res.json({ temp_password: temp });
});

// ---------- generic CRUD ----------
function crudRoutes(table, module, fields, searchable) {
  app.get(`/api/${table}`, auth, need(module, 'view'), (req, res) => {
    const s = (req.query.q || '').trim();
    let rows;
    if (s) {
      const like = `%${s}%`;
      rows = q.all(`SELECT * FROM ${table} WHERE ${searchable.map(f => f + ' LIKE ?').join(' OR ')} ORDER BY id DESC LIMIT 500`, ...searchable.map(() => like));
    } else {
      rows = q.all(`SELECT * FROM ${table} ORDER BY id DESC LIMIT 500`);
    }
    res.json({ [table]: rows });
  });
  app.post(`/api/${table}`, auth, need(module, 'edit'), (req, res) => {
    const vals = fields.map(f => req.body[f] === undefined ? '' : (typeof req.body[f] === 'number' ? req.body[f] : String(req.body[f]).slice(0, 500)));
    if (!vals[0] || !String(vals[0]).trim()) return res.status(400).json({ error: 'البيانات ناقصة' });
    const r = q.run(`INSERT INTO ${table} (${fields.join(',')}, created_by) VALUES (${fields.map(() => '?').join(',')}, ?)`, ...vals, req.user.id);
    logActivity(req.user.id, 'create', table, r.lastInsertRowid, String(vals[0]));
    res.json({ row: q.get(`SELECT * FROM ${table} WHERE id=?`, r.lastInsertRowid) });
  });
  app.put(`/api/${table}/:id`, auth, need(module, 'edit'), (req, res) => {
    const row = q.get(`SELECT * FROM ${table} WHERE id=?`, req.params.id);
    if (!row) return res.status(404).json({ error: 'مش موجود' });
    const sets = [], vals = [];
    for (const f of fields) if (req.body[f] !== undefined) { sets.push(`${f}=?`); vals.push(typeof req.body[f] === 'number' ? req.body[f] : String(req.body[f]).slice(0, 500)); }
    if (table === 'customers') { sets.push("updated_at=datetime('now')"); }
    if (sets.length) q.run(`UPDATE ${table} SET ${sets.join(',')} WHERE id=?`, ...vals, row.id);
    logActivity(req.user.id, 'update', table, row.id, String(req.body.name || req.body.title || row.name || row.title || ''));
    res.json({ row: q.get(`SELECT * FROM ${table} WHERE id=?`, row.id) });
  });
  app.delete(`/api/${table}/:id`, auth, need(module, 'edit'), (req, res) => {
    const row = q.get(`SELECT * FROM ${table} WHERE id=?`, req.params.id);
    if (!row) return res.status(404).json({ error: 'مش موجود' });
    q.run(`DELETE FROM ${table} WHERE id=?`, row.id);
    logActivity(req.user.id, 'delete', table, row.id, String(row.name || row.title || ''));
    res.json({ ok: true });
  });
}
crudRoutes('customers', 'customers', ['name', 'phone', 'company', 'area', 'notes'], ['name', 'phone', 'company', 'area']);
crudRoutes('suppliers', 'suppliers', ['name', 'phone', 'company', 'category', 'notes'], ['name', 'phone', 'company', 'category']);

// offers (status/amount validation)
app.get('/api/offers', auth, need('offers', 'view'), (req, res) => {
  const s = (req.query.q || '').trim(), st = (req.query.status || '').trim();
  let sql = `SELECT o.*, c.name AS customer_name FROM offers o LEFT JOIN customers c ON c.id=o.customer_id`;
  const cond = [], vals = [];
  if (st) { cond.push('o.status=?'); vals.push(st); }
  if (s) { cond.push('(o.title LIKE ? OR c.name LIKE ?)'); vals.push(`%${s}%`, `%${s}%`); }
  if (cond.length) sql += ' WHERE ' + cond.join(' AND ');
  sql += ' ORDER BY o.id DESC LIMIT 500';
  res.json({ offers: q.all(sql, ...vals) });
});
function offerBody(b) {
  const status = ['pending', 'accepted', 'rejected'].includes(b.status) ? b.status : 'pending';
  return [b.customer_id ? Number(b.customer_id) : null, String(b.title || '').slice(0, 200),
    Number(b.amount) || 0, status, String(b.offer_date || new Date().toISOString().slice(0, 10)),
    String(b.notes || '').slice(0, 500)];
}
app.post('/api/offers', auth, need('offers', 'edit'), (req, res) => {
  const v = offerBody(req.body || {});
  if (!v[1].trim()) return res.status(400).json({ error: 'عنوان العرض مطلوب' });
  const r = q.run('INSERT INTO offers (customer_id, title, amount, status, offer_date, notes, created_by) VALUES (?,?,?,?,?,?,?)', ...v, req.user.id);
  logActivity(req.user.id, 'create', 'offers', r.lastInsertRowid, v[1]);
  res.json({ row: q.get('SELECT * FROM offers WHERE id=?', r.lastInsertRowid) });
});
app.put('/api/offers/:id', auth, need('offers', 'edit'), (req, res) => {
  const row = q.get('SELECT * FROM offers WHERE id=?', req.params.id);
  if (!row) return res.status(404).json({ error: 'مش موجود' });
  const v = offerBody({ ...row, ...(req.body || {}) });
  q.run('UPDATE offers SET customer_id=?, title=?, amount=?, status=?, offer_date=?, notes=? WHERE id=?', ...v, row.id);
  logActivity(req.user.id, 'update', 'offers', row.id, v[1]);
  res.json({ row: q.get('SELECT * FROM offers WHERE id=?', row.id) });
});
app.delete('/api/offers/:id', auth, need('offers', 'edit'), (req, res) => {
  const row = q.get('SELECT * FROM offers WHERE id=?', req.params.id);
  if (!row) return res.status(404).json({ error: 'مش موجود' });
  q.run('DELETE FROM offers WHERE id=?', row.id);
  logActivity(req.user.id, 'delete', 'offers', row.id, row.title);
  res.json({ ok: true });
});

// appointments
app.get('/api/appointments', auth, need('appointments', 'view'), (req, res) => {
  res.json({
    appointments: q.all(`SELECT a.*, c.name AS customer_name FROM appointments a
      LEFT JOIN customers c ON c.id=a.customer_id ORDER BY a.done, a.appointment_at LIMIT 500`)
  });
});
app.post('/api/appointments', auth, need('appointments', 'edit'), (req, res) => {
  const b = req.body || {};
  if (!b.title || !b.appointment_at) return res.status(400).json({ error: 'العنوان والمعاد مطلوبين' });
  const at = new Date(b.appointment_at);
  if (isNaN(at)) return res.status(400).json({ error: 'معاد غير صحيح' });
  const r = q.run('INSERT INTO appointments (title, customer_id, appointment_at, notes, created_by) VALUES (?,?,?,?,?)',
    String(b.title).slice(0, 200), b.customer_id ? Number(b.customer_id) : null, at.toISOString(),
    String(b.notes || '').slice(0, 500), req.user.id);
  logActivity(req.user.id, 'create', 'appointments', r.lastInsertRowid, String(b.title));
  res.json({ row: q.get('SELECT * FROM appointments WHERE id=?', r.lastInsertRowid) });
});
app.put('/api/appointments/:id', auth, need('appointments', 'edit'), (req, res) => {
  const row = q.get('SELECT * FROM appointments WHERE id=?', req.params.id);
  if (!row) return res.status(404).json({ error: 'مش موجود' });
  const b = req.body || {};
  const at = b.appointment_at ? new Date(b.appointment_at) : new Date(row.appointment_at);
  if (isNaN(at)) return res.status(400).json({ error: 'معاد غير صحيح' });
  q.run('UPDATE appointments SET title=?, customer_id=?, appointment_at=?, notes=?, done=? WHERE id=?',
    b.title !== undefined ? String(b.title).slice(0, 200) : row.title,
    b.customer_id !== undefined ? (b.customer_id ? Number(b.customer_id) : null) : row.customer_id,
    at.toISOString(), b.notes !== undefined ? String(b.notes).slice(0, 500) : row.notes,
    b.done !== undefined ? (b.done ? 1 : 0) : row.done, row.id);
  logActivity(req.user.id, 'update', 'appointments', row.id, String(b.title || row.title));
  res.json({ row: q.get('SELECT * FROM appointments WHERE id=?', row.id) });
});
app.delete('/api/appointments/:id', auth, need('appointments', 'edit'), (req, res) => {
  q.run('DELETE FROM appointments WHERE id=?', req.params.id);
  logActivity(req.user.id, 'delete', 'appointments', Number(req.params.id), '');
  res.json({ ok: true });
});

// reminders: overdue + next 24h
app.get('/api/reminders', auth, need('appointments', 'view'), (req, res) => {
  const rows = q.all(`SELECT a.*, c.name AS customer_name FROM appointments a
    LEFT JOIN customers c ON c.id=a.customer_id
    WHERE a.done=0 AND a.appointment_at <= datetime('now','+1 day') ORDER BY a.appointment_at LIMIT 50`);
  const now = Date.now();
  res.json({ reminders: rows.map(r => ({ ...r, overdue: new Date(r.appointment_at).getTime() < now })) });
});

// ---------- dashboard & reports ----------
app.get('/api/dashboard', auth, (req, res) => {
  const u = req.user;
  const out = {};
  if (can(u, 'customers', 'view')) out.customers = q.get('SELECT COUNT(*) n FROM customers').n;
  if (can(u, 'suppliers', 'view')) out.suppliers = q.get('SELECT COUNT(*) n FROM suppliers').n;
  if (can(u, 'offers', 'view')) {
    out.offers = q.all('SELECT status, COUNT(*) n, COALESCE(SUM(amount),0) total FROM offers GROUP BY status');
    out.recent_offers = q.all(`SELECT o.id, o.title, o.amount, o.status, o.offer_date, c.name customer_name
      FROM offers o LEFT JOIN customers c ON c.id=o.customer_id ORDER BY o.id DESC LIMIT 5`);
  }
  if (can(u, 'appointments', 'view')) {
    out.today = q.all(`SELECT a.id, a.title, a.appointment_at, c.name customer_name FROM appointments a
      LEFT JOIN customers c ON c.id=a.customer_id
      WHERE a.done=0 AND date(a.appointment_at) <= date('now','+1 day') ORDER BY a.appointment_at LIMIT 10`);
  }
  out.recent_activity = q.all(`SELECT a.action, a.entity, a.details, a.created_at, u.name user_name
    FROM activity a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 10`);
  res.json(out);
});

app.get('/api/reports/summary', auth, need('reports', 'view'), (req, res) => {
  const from = String(req.query.from || '2000-01-01'), to = String(req.query.to || '2100-01-01');
  const offers = q.all(`SELECT status, COUNT(*) n, COALESCE(SUM(amount),0) total FROM offers
    WHERE offer_date BETWEEN ? AND ? GROUP BY status`, from, to);
  const byCustomer = q.all(`SELECT c.name, COUNT(o.id) n, COALESCE(SUM(o.amount),0) total FROM offers o
    JOIN customers c ON c.id=o.customer_id WHERE o.offer_date BETWEEN ? AND ?
    GROUP BY o.customer_id ORDER BY total DESC LIMIT 20`, from, to);
  const appts = q.get(`SELECT COUNT(*) n, SUM(done) done FROM appointments WHERE date(appointment_at) BETWEEN ? AND ?`, from, to);
  res.json({ offers, byCustomer, appointments: appts });
});

const CSV_EN = { 'الاسم': 'Name', 'التليفون': 'Phone', 'الشركة': 'Company', 'المنطقة': 'Area', 'ملاحظات': 'Notes', 'تاريخ الإضافة': 'Date added', 'العرض': 'Offer', 'العميل': 'Customer', 'المبلغ': 'Amount', 'الحالة': 'Status', 'التاريخ': 'Date', 'التصنيف': 'Category', 'المعاد': 'Appointment', 'تم؟': 'Done?' };
function csv(res, filename, headers, rows, lang) {
  lang = lang || res.req.query.lang;
  if (lang === 'en') headers = headers.map(h => CSV_EN[h] || h);
  const esc = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
  const body = '﻿' + [headers.map(esc).join(','), ...rows.map(r => r.map(esc).join(','))].join('\r\n');
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', `attachment; filename="${filename}"`);
  res.send(body);
}
app.get('/api/reports/customers.csv', auth, need('reports', 'view'), (req, res) =>
  csv(res, 'customers.csv', ['الاسم', 'التليفون', 'الشركة', 'المنطقة', 'ملاحظات', 'تاريخ الإضافة'],
    q.all('SELECT name,phone,company,area,notes,created_at FROM customers ORDER BY id').map(r => Object.values(r))));
app.get('/api/reports/offers.csv', auth, need('reports', 'view'), (req, res) => {
  const st = req.query.lang === 'en' ? { pending: 'Pending', accepted: 'Accepted', rejected: 'Rejected' } : { pending: 'معلق', accepted: 'مقبول', rejected: 'مرفوض' };
  csv(res, 'offers.csv', ['العرض', 'العميل', 'المبلغ', 'الحالة', 'التاريخ', 'ملاحظات'],
    q.all(`SELECT o.title, c.name, o.amount, o.status, o.offer_date, o.notes FROM offers o
      LEFT JOIN customers c ON c.id=o.customer_id ORDER BY o.id`)
      .map(r => [r.title, r.name, r.amount, st[r.status] || r.status, r.offer_date, r.notes]));
});
app.get('/api/reports/suppliers.csv', auth, need('reports', 'view'), (req, res) =>
  csv(res, 'suppliers.csv', ['الاسم', 'التليفون', 'الشركة', 'التصنيف', 'ملاحظات'],
    q.all('SELECT name,phone,company,category,notes FROM suppliers ORDER BY id').map(r => Object.values(r))));
app.get('/api/reports/appointments.csv', auth, need('reports', 'view'), (req, res) =>
  csv(res, 'appointments.csv', ['المعاد', 'العميل', 'التاريخ', 'تم؟', 'ملاحظات'],
    q.all(`SELECT a.title, c.name, a.appointment_at, a.done, a.notes FROM appointments a
      LEFT JOIN customers c ON c.id=a.customer_id ORDER BY a.appointment_at`)
      .map(r => [r.title, r.name, r.appointment_at, r.done ? (req.query.lang === 'en' ? 'Yes' : 'نعم') : (req.query.lang === 'en' ? 'No' : 'لا'), r.notes])));

app.get('/api/health', (req, res) => res.json({ ok: true }));

// ---------- static ----------
app.use(express.static(path.join(__dirname, 'public'), { maxAge: 0, etag: true, index: 'index.html' }));

// ---------- seed admin ----------
function seed() {
  if (q.get('SELECT COUNT(*) n FROM users').n > 0) return;
  const un = (process.env.ADMIN_USERNAME || 'aziz').toLowerCase();
  const pw = process.env.ADMIN_PASSWORD || crypto.randomBytes(6).toString('hex');
  q.run('INSERT INTO users (username, name, password_hash, role) VALUES (?,?,?,?)',
    un, process.env.ADMIN_NAME || 'عزيز', bcrypt.hashSync(pw, 10), 'admin');
  console.log('Seeded admin user:', un);
  if (process.env.SEED_DEMO === '1') {
    const c1 = q.run("INSERT INTO customers (name, phone, company, area, notes) VALUES ('أحمد سمير','01001234567','شركة المقاولات المتحدة','مدينة نصر','مهتم بكاميرات الجراج')").lastInsertRowid;
    const c2 = q.run("INSERT INTO customers (name, phone, company, area, notes) VALUES ('م. كريم فؤاد','01009876543','المهندسين للتطوير','التجمع','عرض بوابات SKIDATA')").lastInsertRowid;
    q.run("INSERT INTO customers (name, phone, company, area) VALUES ('هشام عبد الله','01112223334','بيت التعمير','الشروق')");
    q.run("INSERT INTO offers (customer_id, title, amount, status, offer_date, notes) VALUES (?,?,?,?,?,?)",
      c1, 'توريد وتركيب ١٦ كاميرا + NVR', 85000, 'pending', new Date().toISOString().slice(0, 10), 'في انتظار اعتماد الاستشاري');
    q.run("INSERT INTO offers (customer_id, title, amount, status, offer_date, notes) VALUES (?,?,?,?,?,?)",
      c2, 'بوابات دخول وخروج + سوفتوير', 240000, 'accepted', new Date(Date.now() - 864e5 * 6).toISOString().slice(0, 10), 'تم التعاقد');
    q.run("INSERT INTO offers (customer_id, title, amount, status, offer_date, notes) VALUES (?,?,?,?,?,?)",
      c2, 'صيانة سنوية سنترال', 18000, 'rejected', new Date(Date.now() - 864e5 * 12).toISOString().slice(0, 10), 'السعر أعلى من المنافس');
    q.run("INSERT INTO suppliers (name, phone, company, category) VALUES ('محمود رزق','01055556666','هايك فيجن مصر','كاميرات مراقبة')");
    q.run("INSERT INTO suppliers (name, phone, company, category) VALUES ('شركة الأهرام للتوريدات','0223456789','الأهرام','كابلات وأنظمة')");
    q.run("INSERT INTO appointments (title, customer_id, appointment_at, notes) VALUES (?,?,?,?)",
      'معاينة موقع جراج العبور', c1, new Date(Date.now() + 5 * 36e5).toISOString(), 'مع مهندس الموقع');
    q.run("INSERT INTO appointments (title, customer_id, appointment_at) VALUES (?,?,?)",
      'متابعة عرض الكاميرات', c1, new Date(Date.now() + 30 * 36e5).toISOString());
  }
}
seed();

app.listen(PORT, () => console.log(`CRM listening on :${PORT}`));
